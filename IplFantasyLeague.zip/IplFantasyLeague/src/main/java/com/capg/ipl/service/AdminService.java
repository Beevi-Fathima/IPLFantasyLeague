package com.capg.ipl.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.capg.ipl.entity.Admin;
import com.capg.ipl.entity.Bidder;
import com.capg.ipl.entity.BiddingDetails;
import com.capg.ipl.entity.MatchDetails;
import com.capg.ipl.entity.Team;
import com.capg.ipl.exception.BidderNotFoundException;
import com.capg.ipl.exception.BiddingNotStartedException;
import com.capg.ipl.exception.InvalidAdminException;
import com.capg.ipl.exception.MatchAlreadyInProgressException;
import com.capg.ipl.exception.MatchNotFoundException;
import com.capg.ipl.exception.TeamAlreadyExistException;
import com.capg.ipl.exception.TeamNotFoundException;

@Service
public interface AdminService {
	
	public String loginAdmin(Admin admin) throws InvalidAdminException;//san
	public Admin registerAdmin(Admin admin);//san
	public MatchDetails addMatchDetails(MatchDetails matchDetails) throws MatchAlreadyInProgressException; //nishi
	public Team addTeam(Team team) throws TeamAlreadyExistException;//sahmmi
	public void updateMatch(long matchId,LocalDate date,LocalTime time) throws MatchNotFoundException;//ale
	public void deleteMatchById(long matchId) throws MatchNotFoundException;      //sha
	public List<BiddingDetails> getAllBidders() throws BiddingNotStartedException;  //ni
	public void updateScore(long bidderId,Bidder bidder) throws BidderNotFoundException; //fathi
	public void declareResult(long matchId,long teamId) throws MatchNotFoundException;  //fathi
	public void deleteTeam(long teamId) throws TeamNotFoundException; //ale
	public void updateTeamStatus(long teamId);
	public void setFinalMatch(MatchDetails matchDetails) throws MatchAlreadyInProgressException; //nishi
}
