package com.capg.ipl.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.ipl.entity.BiddingDetails;

@Repository
public interface BiddingRepository extends JpaRepository<BiddingDetails, Long>{
    
	@Query("select b from BiddingDetails b where b.bidder.bidderId =: bidderId")
	public BiddingDetails findBidderById(@Param (value="bidderId") long bidderId);
	
	@Modifying
	@Query("delete BiddingDetails b where b.matchDetails.matchId=:matchId")
	public void deleteMatchById(@Param(value="matchId") long matchId);
}
