package com.capg.ipl.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.ipl.entity.Bidder;
import com.capg.ipl.entity.BiddingDetails;
import com.capg.ipl.entity.MatchDetails;
import com.capg.ipl.entity.Team;
import com.capg.ipl.exception.BidAlreadyExistException;
import com.capg.ipl.exception.BidNotFoundException;
import com.capg.ipl.exception.MatchNotFoundException;
import com.capg.ipl.exception.TeamNotFoundException;
import com.capg.ipl.exception.UserAlreadyExistException;
import com.capg.ipl.exception.UserNotFoundException;
import com.capg.ipl.repository.BidderRepository;
import com.capg.ipl.repository.BiddingRepository;
import com.capg.ipl.repository.MatchRepository;
import com.capg.ipl.repository.TeamRepository;

@Service
public class BidderServiceImpl implements BidderService{
	
	@Autowired
	private BidderRepository bidderRepo;
	
	@Autowired
	private MatchRepository matchRepo;
	
	@Autowired
	private TeamRepository teamRepo;
	
	@Autowired
	private BiddingRepository biddingRepo;
	

	@Override
	public Bidder registerBidder(Bidder bidder) throws UserAlreadyExistException{
//		if(bidderRepo.findByUserName(bidder.getUserName()).isEmpty() && bidderRepo.findByName(bidder.getBidderName()).isEmpty()) {
//		      return bidderRepo.save(bidder);
//	    }
//		else {
//			throw new UserAlreadyExistException();
//		}
		if(bidderRepo.existsById(bidder.getBidderId())) {
			throw new UserAlreadyExistException();
		}
	    return bidderRepo.save(bidder);
		
	}

	

	@Override
	public String bidderLogin(Bidder bidder) throws UserNotFoundException{
		if(bidderRepo.userExist(bidder.getUserName(),bidder.getPassword()).isEmpty()) {
			throw new UserNotFoundException();
		}
		else {
			return "Login successful";
		}
	}

	@Override
	public int viewPoints(long bidderId) {
		// TODO Auto-generated method stub
		Bidder bidder = bidderRepo.getOne(bidderId);
		return bidder.getPoints();
	}



	@Override
	public void deleteBid(long biddingId) throws BidNotFoundException{
		if(biddingRepo.findById(biddingId).isEmpty()) {
			throw new BidNotFoundException();
		}
		else {
			BiddingDetails bd = biddingRepo.getOne(biddingId);
			biddingRepo.delete(bd);
		}
		
		
	}

    @Override
	public List<MatchDetails> viewAllMatches()throws MatchNotFoundException {
    	if(matchRepo.findAll().isEmpty()) {
    		throw new MatchNotFoundException();
    	}
		return matchRepo.findAll();
	}



	@Override
	public BiddingDetails addBid(BiddingDetails biddingDetails) throws TeamNotFoundException,BidAlreadyExistException {
		if(biddingRepo.findBidderById(biddingDetails.getBidder().getBidderId())!=null) {
			throw new BidAlreadyExistException();
		}
		else {
			if(matchRepo.existByTeamId(biddingDetails.getTeam().getTeamId())!=null) {
				return biddingRepo.save(biddingDetails);
			}
			else {
				throw new TeamNotFoundException();
			}
		}
	}

    @Override
	public void updateBid(long bidderId, long teamId) throws BidNotFoundException {
		BiddingDetails bd = biddingRepo.findBidderById(bidderId);
		if(bd != null) {
			Team team = new Team();
			team.setTeamId(teamId);
			bd.setTeam(team);
			biddingRepo.save(bd);
		}
		else {
			throw new BidNotFoundException();
		}
		
	}

    @Override
	public String getResult(long matchId) throws MatchNotFoundException{
		if(matchRepo.existsById(matchId)) {
			MatchDetails md = matchRepo.findById(matchId).get();
			Team team = teamRepo.findById(md.getResult()).get();
			return team.getTeamName();
		}
		else {
			throw new MatchNotFoundException();
		}
	}


}
