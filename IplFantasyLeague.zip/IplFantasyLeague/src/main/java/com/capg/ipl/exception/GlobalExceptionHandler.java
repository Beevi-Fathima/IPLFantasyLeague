package com.capg.ipl.exception;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import lombok.val;

@ControllerAdvice
public class GlobalExceptionHandler{
	@Value(value="${message1}")
	private String message1;
	
	@Value(value="${message2}")
	private String message2;
	
	@Value(value="${message3}")
	private String message3;
	
	@Value(value="${message4}")
	private String message4;
	
	@Value(value="${message5}")
	private String message5;
	
	@Value(value="${message6}")
	private String message6;
	
	@Value(value="${message7}")
	private String message7;
	
	@Value(value="${message8}")
	private String message8;
	
	@Value(value="${message9}")
	private String message9;
	
	@Value(value="${message10}")
	private String message10;
	
	@Value(value="${message11}")
	private String message11;
	
	
	@ExceptionHandler(value=InvalidAdminException.class)
	public ResponseEntity InvalidAdminException  (InvalidAdminException ex) {
		return new ResponseEntity(message1,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value=MatchAlreadyInProgressException.class)
	public ResponseEntity  MatchAlreadyInProgressException(MatchAlreadyInProgressException ex) {
		return new ResponseEntity(message2,HttpStatus.CONFLICT);
	}
	
	@ExceptionHandler(value=TeamNotFoundException.class)
	public ResponseEntity TeamNotFoundException(TeamNotFoundException ex) {
		return new ResponseEntity(message3,HttpStatus.CONFLICT);
	}
	
	@ExceptionHandler(value=TeamAlreadyExistException.class)
	public ResponseEntity TeamAlreadyExistException(TeamAlreadyExistException ex) {
		return new ResponseEntity(message4,HttpStatus.ALREADY_REPORTED);
	}
	
	@ExceptionHandler(value=MatchNotFoundException.class)
	public ResponseEntity MatchNotFoundException(MatchNotFoundException ex) {
		return new ResponseEntity(message5,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value=BiddingNotStartedException.class)
	public ResponseEntity BiddingNotStartedException(BiddingNotStartedException ex) {
		return new ResponseEntity(message6,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value=BidderNotFoundException.class)
	public ResponseEntity BidderNotFoundExceptio(BidderNotFoundException ex) {
		return new ResponseEntity(message7,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value=BidAlreadyExistException.class)
	public ResponseEntity BidAlreadyExistException(BidAlreadyExistException ex) {
		return new ResponseEntity(message8,HttpStatus.ALREADY_REPORTED);
	}
	
	@ExceptionHandler(value=UserAlreadyExistException.class)
	public ResponseEntity UserAlreadyExistException(UserAlreadyExistException ex) {
		return new ResponseEntity(message9,HttpStatus.ALREADY_REPORTED);
	}
	
	@ExceptionHandler(value=UserNotFoundException.class)
	public ResponseEntity UserNotFoundException(UserNotFoundException ex) {
		return new ResponseEntity(message10,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value=BidNotFoundException.class)
	public ResponseEntity BidNotFoundException(BidNotFoundException ex) {
		return new ResponseEntity(message11,HttpStatus.NOT_FOUND);
	}
	
	
}
