package com.capg.ipl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.ipl.entity.Bidder;
import com.capg.ipl.entity.BiddingDetails;
import com.capg.ipl.entity.MatchDetails;
import com.capg.ipl.entity.Team;
import com.capg.ipl.exception.BidAlreadyExistException;
import com.capg.ipl.exception.BidNotFoundException;
import com.capg.ipl.exception.MatchNotFoundException;
import com.capg.ipl.exception.TeamNotFoundException;
import com.capg.ipl.exception.UserAlreadyExistException;
import com.capg.ipl.exception.UserNotFoundException;
import com.capg.ipl.service.BidderService;

@RestController
@RequestMapping("/bidder")
public class BidderController {
	
	@Autowired
	private BidderService bidderService;
	
	@PostMapping("/register")
	public Bidder registerBidder(@RequestBody Bidder bidder) throws UserAlreadyExistException {
		return this.bidderService.registerBidder(bidder);
	}
	
	
	
	@GetMapping("/login")
	public String bidderLogin(@RequestBody Bidder bidder) throws UserNotFoundException{
		return this.bidderService.bidderLogin(bidder);
	}
	
//	@PostMapping("/team/{teamId}")
//	public Team viewTeamDetails(@PathVariable long teamId) {
//		return this.bidderService.viewTeamDetails(teamId);
//	}
	
//	@GetMapping("/match/{matchId}")
//	public MatchDetails viewMatchDetails(long matchId) throws ServiceException{
//		return this.bidderService.viewMatchDetails(matchId);
//	}
	
	@GetMapping("/all matches")
	public List<MatchDetails> viewAllMatches() throws MatchNotFoundException {
		return this.bidderService.viewAllMatches();
	}
	
	@GetMapping("/bidding")
	public BiddingDetails addBid(BiddingDetails biddingDetails) throws TeamNotFoundException,BidAlreadyExistException{
		return this.bidderService.addBid(biddingDetails);
	}
    
	@PutMapping("/updateBid/{bidderId}/{teamId}")
	public ResponseEntity<String> updateBid(long bidderId,@PathVariable long teamId) throws BidNotFoundException{
		this.bidderService.updateBid(bidderId, teamId);
		return new ResponseEntity<>("Bid Updated Successfully",HttpStatus.ACCEPTED);
		
	}
	
	@DeleteMapping("/deleteBid/{biddingId}")
	public ResponseEntity<String> deleteBid(@PathVariable long biddingId) throws BidNotFoundException{
		this.bidderService.deleteBid(biddingId);
		return new ResponseEntity<>("Bid Deleted Successfully",HttpStatus.OK);
		
	}
	
	@GetMapping("/result/{matchId}")
	public String getResult(@PathVariable long matchId) throws MatchNotFoundException{
		return this.bidderService.getResult(matchId);
	} 
	

}
