package com.capg.ipl.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.capg.ipl.entity.Admin;
import com.capg.ipl.entity.Bidder;
import com.capg.ipl.entity.BiddingDetails;
import com.capg.ipl.entity.MatchDetails;
import com.capg.ipl.entity.Team;
import com.capg.ipl.exception.BidderNotFoundException;
import com.capg.ipl.exception.BiddingNotStartedException;
import com.capg.ipl.exception.InvalidAdminException;
import com.capg.ipl.exception.MatchAlreadyInProgressException;
import com.capg.ipl.exception.MatchNotFoundException;
import com.capg.ipl.exception.TeamAlreadyExistException;
import com.capg.ipl.exception.TeamNotFoundException;
import com.capg.ipl.repository.AdminRepository;
import com.capg.ipl.repository.BidderRepository;
import com.capg.ipl.repository.BiddingRepository;
import com.capg.ipl.repository.MatchRepository;
import com.capg.ipl.repository.TeamRepository;


@Service
public class AdminServiceImpl implements AdminService{
	@Autowired
	private AdminRepository adminRepo;
	
	@Autowired
	private TeamRepository teamRepo;
	
	@Autowired
	private MatchRepository matchRepo;
	
	@Autowired
	private BiddingRepository biddingRepo;
	
	@Autowired
	private BidderRepository bidderRepo;
    
	@Override
	public Admin registerAdmin(Admin admin) {
		return this.adminRepo.save(admin);
	}
	
	@Override
	public String loginAdmin(Admin admin) throws InvalidAdminException{
		if(adminRepo.findAdmin(admin.getUserName(), admin.getPassword()).isEmpty()) {
			
			throw new InvalidAdminException("Invalid Credentials");
		}
		
		return "Login Successful";
	}

	@Override
	public MatchDetails addMatchDetails(MatchDetails matchDetails) throws MatchAlreadyInProgressException {
		if(matchRepo.count()<=1) {
			return matchRepo.save(matchDetails);
		}
		else {
			if(matchDetails.getResult()!=0 && matchRepo.count()==2) {
				matchRepo.deleteAll();
			}
		}
		throw new MatchAlreadyInProgressException("Match already started");
	}

	@Override
	public Team addTeam(Team team) throws TeamAlreadyExistException{
		if(teamRepo.findByTeamName(team.getTeamName())==null) {
               return teamRepo.save(team);
		}
		else {
			throw new TeamAlreadyExistException("Team Already Exists");
		}
	}

	@Override
	public void updateMatch(long matchId, LocalDate date, LocalTime time) throws MatchNotFoundException {
		if(matchRepo.findAll().isEmpty()) {
			throw new MatchNotFoundException();
		}
		else {
			MatchDetails matchDetails = matchRepo.findById(matchId).get();
			matchDetails.setDate(date);
			matchDetails.setTime(time);
			matchRepo.save(matchDetails);
			
		}
		
	}

	@Override
	public void deleteMatchById(long matchId) throws MatchNotFoundException{
		if(matchRepo.existsById(matchId)) {
			MatchDetails md = matchRepo.findById(matchId).get();
			matchRepo.delete(md);
		}
		
		
	}

	@Override
	public List<BiddingDetails> getAllBidders() throws BiddingNotStartedException {
     	Iterable<BiddingDetails> bd = biddingRepo.findAll();
		List<BiddingDetails> biddingDetails = new ArrayList<>();
		bd.forEach(bidders->{
			BiddingDetails b = new BiddingDetails();
			b.setBidder(bidders.getBidder());
		    b.setBiddingId(bidders.getBiddingId());
		    b.setMatchDetails(bidders.getMatchDetails());
		    b.setTeam(bidders.getTeam());
		    biddingDetails.add(b);
		});
		if(biddingDetails.isEmpty()) {
			throw new BiddingNotStartedException();
		}
		return biddingDetails;
	}

	@Override
	public void updateScore(long bidderId, Bidder bidder) throws BidderNotFoundException {
		if(bidderRepo.existsById(bidderId)) {
			Bidder b = bidderRepo.findById(bidderId).get();
			b.setPoints(bidder.getPoints()+1);
			bidderRepo.save(b);
		}
		else {
			throw new BidderNotFoundException();
		}
		
		
	}

	@Override
	public void declareResult(long matchId,long teamId) throws MatchNotFoundException{
		if(matchRepo.existsById(matchId)) {
			MatchDetails md = matchRepo.findById(matchId).get();
			md.setResult(teamId);
			//long id= teamRepo.findByTeamName(teamName).getTeamId();
			Team teamWon = teamRepo.findById(teamId).get();
			teamWon.setMatchesWon(teamWon.getMatchesWon()+1);
			teamWon.setMatchesPlayed(teamWon.getMatchesPlayed()+1);
			if(md.getTeamOne().getTeamId()
					!=teamId) {
				Team teamLost = md.getTeamOne();
				teamLost.setMatchesLost(teamLost.getMatchesLost()+1);
				teamLost.setMatchesPlayed(teamLost.getMatchesPlayed()+1);
				teamRepo.save(teamLost);
			}
			else {
				Team teamLost = md.getTeamTwo();
				teamLost.setMatchesLost(teamLost.getMatchesLost()+1);
				teamLost.setMatchesPlayed(teamLost.getMatchesPlayed()+1);
				teamRepo.save(teamLost);
			}
			teamRepo.save(teamWon);
			matchRepo.save(md);
			List<Bidder> bidders = bidderRepo.findByMatchId(matchId);
			for(Bidder b:bidders) {
				if(b.getBiddingDetails().getTeam().getTeamId()==teamId) {
					int point = b.getPoints()+1;
					b.setPoints(point);
				}
			}
		}
		else {
			throw new MatchNotFoundException();
		}
		
	}

	@Override
	public void deleteTeam(long teamId) throws TeamNotFoundException{
		Team team = teamRepo.findByTeamId(teamId);
		if(team==null) {
			throw new TeamNotFoundException("Team does not exist");
		}
		else {
			teamRepo.delete(team);
		}
		
	}

	@Override
	public void updateTeamStatus(long teamId) {
		// TODO Auto-generated method stub
		
		
	}
	public void setFinalMatch(MatchDetails matchDetails) throws MatchAlreadyInProgressException{
		List<MatchDetails> list = matchRepo.findAll();
		if(list.get(0).getResult()!=0 && list.get(1).getResult()!=0) {
	        MatchDetails md = new MatchDetails();
	        md.setDate(matchDetails.getDate());
	        md.setTime(matchDetails.getTime());
	        md.setPlace(matchDetails.getPlace());
	        Team teamOne = new Team();
	        teamOne.setTeamId(list.get(0).getResult());
	        md.setTeamOne(teamOne);
	        Team teamTwo = new Team();
	        teamTwo.setTeamId(list.get(1).getResult());
	        md.setTeamTwo(teamTwo);
	        md.setResult(0);
	        md.setStatus("not started");
	        matchRepo.save(matchDetails);
	        
		}
		else {
			throw new MatchAlreadyInProgressException();
		}
	}
	
	
	

}
