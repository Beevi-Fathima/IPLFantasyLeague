package com.capg.ipl.exception;

public class ServiceException extends Exception{
	private String message;
	public ServiceException() {
		super();
	}
	public ServiceException(String message) {
		super();
		this.message = message;
	}
	@Override
	public String toString() {
		return "ServiceException [message=" + message + "]";
	}
}
