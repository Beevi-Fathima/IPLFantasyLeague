package com.capg.ipl.IplFantasyLeague;

 

import static org.mockito.BDDMockito.willDoNothing;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

 

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;

 

import com.capg.ipl.exception.MatchAlreadyInProgressException;
import com.capg.ipl.service.AdminService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

 

@WebMvcTest
public class AdminControllerTest {

 

    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
    private AdminService adminService;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    //WillDoNothing willDoNothing=mock(WillDoNothing.class);
    
    @Test
    public void givenMatchId_whenDeleteMatchById_thenReturn200() throws JsonProcessingException,Exception{
        long matchId=1L;
        willDoNothing().given(adminService).deleteMatchById(matchId);
        ResultActions response=mockMvc.perform(delete("/match/{matchId}",matchId));
        response.andExpect(status().isOk())
        .andDo(print());
    }

 

    private RequestBuilder delete(String string, long matchId) {
        // TODO Auto-generated method stub
        return null;
    }

 

    

 

    
}