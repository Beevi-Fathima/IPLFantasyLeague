package com.capg.ipl.IplFantasyLeague;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IplFantasyLeagueApplicationTests {

	@Test
	void contextLoads() {
	}

}
